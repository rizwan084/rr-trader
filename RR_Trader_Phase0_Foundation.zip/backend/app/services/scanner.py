from __future__ import annotations

from typing import Any

from app.clients.binance import binance_client
from app.core.config import settings


class MarketScanner:
    """
    Phase-0 scanner shell.

    Core decision timeframes are locked to:
    15m, 1h, 4h.
    """

    CORE_TIMEFRAMES = settings.core_timeframes

    async def scan_symbol(
        self,
        symbol: str,
        market: str = "futures",
        limit: int = 200,
    ) -> dict[str, Any]:
        result: dict[str, Any] = {
            "success": True,
            "symbol": symbol.upper(),
            "market": market.lower(),
            "timeframes": {},
        }

        for timeframe in self.CORE_TIMEFRAMES:
            result["timeframes"][timeframe] = {
                "status": "ready_for_phase_2",
            }

        return result

    async def scan(self, market: str = "futures") -> dict[str, Any]:
        return {
            "success": True,
            "market": market.lower(),
            "core_timeframes": list(self.CORE_TIMEFRAMES),
            "deep_analysis_limit": settings.deep_analysis_limit,
            "status": "scanner_engine_pending_phase_2",
        }
