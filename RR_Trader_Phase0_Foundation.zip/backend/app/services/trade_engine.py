from __future__ import annotations


class TradeEngine:
    """Paper-trading shell; live execution is intentionally disabled."""

    mode = "paper"

    def status(self) -> dict:
        return {
            "mode": self.mode,
            "live_trading": False,
            "status": "pending_phase_4",
        }


default_trade_engine = TradeEngine()
