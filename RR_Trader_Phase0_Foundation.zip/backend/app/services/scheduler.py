import asyncio


class Scheduler:
    """Background scheduler shell. No auto-scan loop starts in Phase 0."""

    def __init__(self) -> None:
        self.running = False
        self.task: asyncio.Task | None = None


scheduler = Scheduler()
