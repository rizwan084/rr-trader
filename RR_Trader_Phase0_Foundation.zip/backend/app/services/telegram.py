class TelegramService:
    """Telegram integration shell."""

    async def send_message(self, message: str) -> dict:
        return {
            "success": False,
            "status": "pending_phase_5",
            "message": message,
        }


telegram_service = TelegramService()
