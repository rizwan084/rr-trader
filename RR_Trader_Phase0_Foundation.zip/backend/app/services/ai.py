class AIEngine:
    """AI integration shell; provider calls are added in a later phase."""

    def status(self) -> dict:
        return {
            "enabled": False,
            "status": "pending_phase_5",
        }


ai_engine = AIEngine()
