class SignalMemory:
    """Signal-history shell for later persistence integration."""

    def __init__(self) -> None:
        self._signals: list[dict] = []

    def add(self, signal: dict) -> None:
        self._signals.append(signal)

    def recent(self, limit: int = 50) -> list[dict]:
        return self._signals[-limit:]


signal_memory = SignalMemory()
