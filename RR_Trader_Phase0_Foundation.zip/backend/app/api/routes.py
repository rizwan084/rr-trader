from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Query

from app.core.config import settings


router = APIRouter()


@router.get("/health")
async def health() -> dict[str, Any]:
    return {
        "success": True,
        "status": "healthy",
        "service": "rr-trader",
        "version": settings.app_version,
    }


@router.get("/markets")
async def markets() -> dict[str, Any]:
    return {
        "success": True,
        "markets": [
            {"id": "futures", "name": "Binance Futures", "enabled": True},
            {"id": "spot", "name": "Binance Spot", "enabled": True},
        ],
    }


@router.get("/search")
async def search(
    q: str = Query(default="", min_length=0, max_length=30),
    market: str = Query(default="futures"),
) -> dict[str, Any]:
    clean = q.upper().replace("USDT", "").strip()
    if not clean:
        return {"success": True, "market": market, "coins": []}

    # Phase 0 intentionally keeps search lightweight.
    symbol = f"{clean}USDT"
    return {
        "success": True,
        "market": market,
        "coins": [{"symbol": symbol, "coin": clean}],
    }


@router.get("/analyze")
async def analyze(
    symbol: str,
    market: str = Query(default="futures"),
) -> dict[str, Any]:
    return {
        "success": True,
        "symbol": symbol.upper(),
        "market": market.lower(),
        "status": "analysis_engine_pending_phase_2",
    }


@router.get("/scan")
async def scan(
    market: str = Query(default="futures"),
) -> dict[str, Any]:
    return {
        "success": True,
        "market": market.lower(),
        "status": "scanner_pending_phase_2",
        "core_timeframes": list(settings.core_timeframes),
    }


@router.get("/signals")
async def signals() -> dict[str, Any]:
    return {
        "success": True,
        "signals": [],
        "status": "signal_engine_pending_phase_3",
    }
