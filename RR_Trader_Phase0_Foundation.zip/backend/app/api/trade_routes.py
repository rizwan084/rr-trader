from __future__ import annotations

from typing import Any

from fastapi import APIRouter


router = APIRouter()


@router.get("/trade/status")
async def trade_status() -> dict[str, Any]:
    return {
        "success": True,
        "mode": "paper",
        "status": "trade_engine_pending_phase_4",
    }


@router.get("/trade/positions")
async def positions() -> dict[str, Any]:
    return {
        "success": True,
        "positions": [],
    }


@router.get("/trade/history")
async def history() -> dict[str, Any]:
    return {
        "success": True,
        "trades": [],
    }
