from __future__ import annotations

from typing import Any, Optional

import httpx

from app.core.config import settings


class BinanceClient:
    """Shared async Binance market-data client for Spot and Futures."""

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._semaphore = __import__("asyncio").Semaphore(8)

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            limits = httpx.Limits(
                max_connections=settings.http_max_connections,
                max_keepalive_connections=settings.http_max_keepalive,
            )
            self._client = httpx.AsyncClient(
                timeout=settings.request_timeout,
                limits=limits,
                headers={
                    "User-Agent": "RR-Trader/1.0",
                    "Accept": "application/json",
                },
            )
        return self._client

    def _base_url(self, market: str) -> str:
        market = market.lower().strip()
        if market == "futures":
            return settings.binance_futures_url.rstrip("/")
        if market == "spot":
            return settings.binance_spot_url.rstrip("/")
        raise ValueError("market must be 'spot' or 'futures'")

    async def get(
        self,
        path: str,
        *,
        market: str = "futures",
        params: Optional[dict[str, Any]] = None,
    ) -> Any:
        client = await self._get_client()
        url = f"{self._base_url(market)}{path}"

        async with self._semaphore:
            response = await client.get(url, params=params)
            response.raise_for_status()
            return response.json()

    async def exchange_info(self, market: str = "futures") -> dict[str, Any]:
        path = "/fapi/v1/exchangeInfo" if market == "futures" else "/api/v3/exchangeInfo"
        return await self.get(path, market=market)

    async def ticker_24h(self, market: str = "futures") -> Any:
        path = "/fapi/v1/ticker/24hr" if market == "futures" else "/api/v3/ticker/24hr"
        return await self.get(path, market=market)

    async def klines(
        self,
        symbol: str,
        interval: str,
        *,
        market: str = "futures",
        limit: int = 200,
    ) -> Any:
        path = "/fapi/v1/klines" if market == "futures" else "/api/v3/klines"
        return await self.get(
            path,
            market=market,
            params={
                "symbol": symbol.upper(),
                "interval": interval,
                "limit": limit,
            },
        )

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None


binance_client = BinanceClient()
