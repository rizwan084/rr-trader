from fastapi.testclient import TestClient

from backend.app.main import app

client = TestClient(app)


def test_health() -> None:
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["success"] is True


def test_markets() -> None:
    response = client.get("/api/markets")
    assert response.status_code == 200
    assert {m["id"] for m in response.json()["markets"]} == {"spot", "futures"}
